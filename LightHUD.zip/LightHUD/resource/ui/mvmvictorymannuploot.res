"Resource/UI/MvMVictoryMannUpLoot.res"
{
	"Marker"
	{
		"ControlName"								"CExLabel"
		"fieldName"									"Marker"
		"xpos"										"0"
		"ypos"										"0"
		"wide"										"32"
		"tall"										"32"
		"font"										"HudFontSmallestBold"
		"labelText"									"X"
		"textAlignment"								"center"
		"fgcolor"									"Red"
	}
	"EconItemModel"
	{
		"ControlName"								"CItemModelPanel"
		"fieldName"									"EconItemModel"
		"xpos"										"0"
		"ypos"										"6"
		"wide"										"32"
		"tall"										"20"
		"visible"									"1"
		"bgcolor_override"							"Blank"
		"PaintBackgroundType"						"0"
		"paintborder"								"0"

		"model_ypos"								"0"
		"model_tall"								"20"
		"model_wide"								"32"
		"name_only"									"0"
		"attrib_only"								"0"
		"model_only"								"1"
		"paint_icon_hide"							"1"

		"ItemModelPanel"
		{
			"use_item_rendertarget"					"0"
			"inventory_image_type"					"1"
			"allow_rot"								"0"
		}
	}
}