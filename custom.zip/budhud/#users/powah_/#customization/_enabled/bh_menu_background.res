"Resource/UI/MainMenuOverride.res"
{
    MainMenuOverride
    {
    }

    "Background"
    {
        "image"                                                     "replay/thumbnails/#users/background_powah"
    }
}